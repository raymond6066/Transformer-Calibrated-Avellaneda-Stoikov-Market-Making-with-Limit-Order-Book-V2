# Transformer-Calibrated Avellaneda-Stoikov Market Making

This repository is a research scaffold for an MScFE 690 capstone project. It uses Level-10 limit order book (LOB) windows to forecast short-horizon volatility and liquidity states, then calibrates those forecasts into an Avellaneda-Stoikov market-making simulator.

The project is a controlled research simulator, not a live trading bot. It does not connect to brokers or exchanges.

## Research question

To what extent does a compact spatio-temporal transformer trained on Level-10 LOB depth and tick history improve short-horizon volatility and liquidity calibration for an Avellaneda-Stoikov market-making strategy, relative to rolling-statistical models and MLP baselines?

## Repository layout

```text
config/default.yaml                  Experiment configuration
scripts/train.py                     Training entry point scaffold
scripts/backtest.py                  Backtest entry point scaffold
src/lob_as_calibrator/data           Loading, preprocessing, and datasets
src/lob_as_calibrator/features       Order-book features and labels
src/lob_as_calibrator/models         Rolling, EWMA, MLP, and transformer models
src/lob_as_calibrator/calibration    Map predictions to sigma^2 and k
src/lob_as_calibrator/market_making  AS quotes, fills, and simulator
src/lob_as_calibrator/evaluation     Forecasting and backtest metrics
notebooks/.gitkeep                   Place for EDA notebooks
tests                                Unit tests for validity and accounting
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
pytest
```

## Data expectations

The code expects FI-2010-style Level-10 LOB data or a CSV/DataFrame with columns named like:

```text
ask_price_1, ask_size_1, bid_price_1, bid_size_1, ..., ask_price_10, ask_size_10, bid_price_10, bid_size_10
```

If your raw FI-2010 files are in matrix form, use `load_fi2010_matrix` and inspect the returned feature and label arrays before building model windows.

## Evaluation plan

1. Build chronological train/validation/test splits.
2. Fit normalizers on train data only.
3. Build future realized variance and liquidity labels.
4. Train rolling, EWMA, MLP, and compact transformer baselines.
5. Convert predictions into `sigma2_hat` and `k_hat`.
6. Replay the test period through the Avellaneda-Stoikov simulator.
7. Compare forecast errors and strategy risk metrics.

Key metrics include MAE, RMSE, R-squared, QLIKE, maximum drawdown, inventory exposure, CVaR, fill rate, and quote behavior.

## Safety and validity rules

- Do not use randomized splits for event-time LOB experiments.
- Do not fit scalers on validation or test data.
- Do not align labels so that future data leaks into inputs.
- Do not judge market-making performance by P&L alone.
- Do not claim production profitability from this simulator.

## Suggested Codex workflow

Open this repository in VS Code or GitHub Codespaces, then paste the instructions in `CODEX_PROMPT.md` into Codex. Ask Codex to implement one module at a time, run tests after each change, and preserve the no-leakage tests.
