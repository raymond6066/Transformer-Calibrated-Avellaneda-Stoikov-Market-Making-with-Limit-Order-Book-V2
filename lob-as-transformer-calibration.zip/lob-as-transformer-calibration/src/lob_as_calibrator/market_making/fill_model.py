"""Simplified fill model for research replay."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FillResult:
    """Whether bid and ask quotes were filled."""

    bid_filled: bool
    ask_filled: bool


def touch_fill_model(bid: float, ask: float, future_low: float, future_high: float) -> FillResult:
    """Fill quotes if future mid-price range touches quoted levels.

    This is intentionally simplified and should be replaced with a queue-aware
    model for stronger empirical claims.
    """
    return FillResult(bid_filled=future_low <= bid, ask_filled=future_high >= ask)
