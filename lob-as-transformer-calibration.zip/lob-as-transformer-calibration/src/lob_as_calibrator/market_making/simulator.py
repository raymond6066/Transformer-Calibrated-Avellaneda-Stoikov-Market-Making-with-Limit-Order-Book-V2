"""Event-time Avellaneda-Stoikov replay simulator."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from lob_as_calibrator.market_making.avellaneda_stoikov import ASParams, inventory_allowed, make_quotes
from lob_as_calibrator.market_making.fill_model import touch_fill_model


@dataclass
class AccountState:
    """Cash and inventory state."""

    cash: float = 0.0
    inventory: int = 0

    def mark_to_market(self, mid: float) -> float:
        return float(self.cash + self.inventory * mid)


def update_account(state: AccountState, bid: float, ask: float, bid_filled: bool, ask_filled: bool) -> AccountState:
    """Update cash and inventory after fills.

    Bid fill means the strategy buys one unit at bid. Ask fill means it sells
    one unit at ask.
    """
    cash = state.cash
    inventory = state.inventory
    if bid_filled:
        cash -= bid
        inventory += 1
    if ask_filled:
        cash += ask
        inventory -= 1
    return AccountState(cash=float(cash), inventory=int(inventory))


def replay_as_strategy(
    mid_prices: np.ndarray,
    sigma2_hat: np.ndarray,
    k_hat: np.ndarray,
    params: ASParams,
    lookahead: int = 10,
    initial_cash: float = 0.0,
) -> pd.DataFrame:
    """Replay AS quotes over a mid-price series with a simplified touch-fill model."""
    mid_prices = np.asarray(mid_prices, dtype=float)
    sigma2_hat = np.asarray(sigma2_hat, dtype=float)
    k_hat = np.asarray(k_hat, dtype=float)
    n = min(len(mid_prices), len(sigma2_hat), len(k_hat))
    state = AccountState(cash=initial_cash, inventory=0)
    records: list[dict[str, float | int | bool]] = []

    for t in range(0, n - lookahead):
        tau = max((n - t) / n, 1.0e-6)
        bid, ask = make_quotes(mid_prices[t], state.inventory, sigma2_hat[t], k_hat[t], tau, params)
        future = mid_prices[t + 1 : t + lookahead + 1]
        fills = touch_fill_model(bid, ask, float(np.min(future)), float(np.max(future)))
        bid_filled = fills.bid_filled and inventory_allowed(state.inventory, "buy", params.max_inventory)
        ask_filled = fills.ask_filled and inventory_allowed(state.inventory, "sell", params.max_inventory)
        state = update_account(state, bid, ask, bid_filled, ask_filled)
        records.append({
            "t": t,
            "mid": mid_prices[t],
            "sigma2_hat": sigma2_hat[t],
            "k_hat": k_hat[t],
            "bid": bid,
            "ask": ask,
            "bid_filled": bid_filled,
            "ask_filled": ask_filled,
            "cash": state.cash,
            "inventory": state.inventory,
            "pnl": state.mark_to_market(mid_prices[t]),
        })
    return pd.DataFrame.from_records(records)
