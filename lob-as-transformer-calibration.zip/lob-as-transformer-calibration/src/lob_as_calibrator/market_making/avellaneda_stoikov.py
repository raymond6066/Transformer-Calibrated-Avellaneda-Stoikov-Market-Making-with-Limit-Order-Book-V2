"""Avellaneda-Stoikov quote equations."""

from __future__ import annotations

from dataclasses import dataclass
from math import log

import numpy as np


@dataclass(frozen=True)
class ASParams:
    """Parameters for Avellaneda-Stoikov quote generation."""

    gamma: float = 0.01
    tick_size: float = 0.01
    max_inventory: int | None = None


def round_to_tick(price: float, tick_size: float) -> float:
    """Round a price to the nearest tick."""
    if tick_size <= 0:
        raise ValueError("tick_size must be positive")
    return round(price / tick_size) * tick_size


def reservation_price(mid: float, inventory: float, gamma: float, sigma2: float, tau: float) -> float:
    """Compute AS reservation price."""
    return float(mid - inventory * gamma * sigma2 * tau)


def optimal_spread(gamma: float, sigma2: float, tau: float, k: float) -> float:
    """Compute AS optimal spread with positive k."""
    if gamma <= 0:
        raise ValueError("gamma must be positive")
    if k <= 0:
        raise ValueError("k must be positive")
    return float(gamma * sigma2 * tau + (2.0 / gamma) * log(1.0 + gamma / k))


def make_quotes(mid: float, inventory: float, sigma2: float, k: float, tau: float, params: ASParams) -> tuple[float, float]:
    """Generate bid and ask quotes."""
    r = reservation_price(mid, inventory, params.gamma, sigma2, tau)
    spread = optimal_spread(params.gamma, sigma2, tau, k)
    bid = round_to_tick(r - spread / 2.0, params.tick_size)
    ask = round_to_tick(r + spread / 2.0, params.tick_size)
    if bid >= ask:
        ask = bid + params.tick_size
    return float(bid), float(ask)


def inventory_allowed(inventory: float, side: str, max_inventory: int | None) -> bool:
    """Return whether a new fill on side buy/sell is allowed under inventory limits."""
    if max_inventory is None:
        return True
    if side == "buy":
        return inventory < max_inventory
    if side == "sell":
        return inventory > -max_inventory
    raise ValueError("side must be 'buy' or 'sell'")
