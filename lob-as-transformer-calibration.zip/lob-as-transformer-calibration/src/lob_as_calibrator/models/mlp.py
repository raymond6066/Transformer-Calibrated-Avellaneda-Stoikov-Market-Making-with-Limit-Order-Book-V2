"""MLP baseline for LOB state prediction."""

from __future__ import annotations

try:
    import torch
    from torch import nn
except Exception:  # pragma: no cover
    torch = None
    nn = None


class MLPForecastModel(nn.Module if nn is not None else object):
    """Simple feed-forward baseline for flattened LOB windows."""

    def __init__(self, input_dim: int, output_dim: int, hidden_sizes: list[int], dropout: float = 0.1) -> None:
        if nn is None:
            raise ImportError("Install torch to use MLPForecastModel")
        super().__init__()
        layers: list[nn.Module] = []
        prev = input_dim
        for hidden in hidden_sizes:
            layers.extend([nn.Linear(prev, hidden), nn.ReLU(), nn.Dropout(dropout)])
            prev = hidden
        layers.append(nn.Linear(prev, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        if x.ndim == 3:
            x = x.flatten(start_dim=1)
        return self.net(x)
