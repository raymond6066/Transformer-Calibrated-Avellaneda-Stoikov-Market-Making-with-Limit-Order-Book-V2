"""Loss functions for volatility and liquidity forecasting."""

from __future__ import annotations

import numpy as np


def qlike_loss(y_true_var: np.ndarray, y_pred_var: np.ndarray, eps: float = 1.0e-12) -> float:
    """Compute QLIKE loss for variance forecasts."""
    y = np.asarray(y_true_var, dtype=float).clip(min=eps)
    pred = np.asarray(y_pred_var, dtype=float).clip(min=eps)
    return float(np.mean(np.log(pred) + y / pred))


def weighted_mse_components(errors: dict[str, np.ndarray], weights: dict[str, float] | None = None) -> float:
    """Combine component MSE losses using optional weights."""
    weights = weights or {name: 1.0 for name in errors}
    total = 0.0
    denom = 0.0
    for name, err in errors.items():
        w = weights.get(name, 1.0)
        total += w * float(np.mean(np.asarray(err) ** 2))
        denom += w
    return total / max(denom, 1.0e-12)
