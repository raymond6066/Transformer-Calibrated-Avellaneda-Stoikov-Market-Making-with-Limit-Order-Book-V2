"""Statistical volatility baselines."""

from __future__ import annotations

import numpy as np


class RollingVolatility:
    """Rolling realized variance baseline."""

    def __init__(self, window: int = 100, eps: float = 1.0e-12) -> None:
        self.window = int(window)
        self.eps = float(eps)

    def predict_log_variance(self, log_returns: np.ndarray) -> np.ndarray:
        r = np.asarray(log_returns, dtype=float)
        out = np.full_like(r, fill_value=np.nan, dtype=float)
        squared = r**2
        for t in range(len(r)):
            start = max(0, t - self.window + 1)
            out[t] = np.log(self.eps + squared[start : t + 1].sum())
        return out


class EWMAVolatility:
    """Exponentially weighted moving variance baseline."""

    def __init__(self, lam: float = 0.94, eps: float = 1.0e-12) -> None:
        if not 0.0 < lam < 1.0:
            raise ValueError("lam must be between 0 and 1")
        self.lam = float(lam)
        self.eps = float(eps)

    def predict_log_variance(self, log_returns: np.ndarray) -> np.ndarray:
        r = np.asarray(log_returns, dtype=float)
        out = np.zeros_like(r, dtype=float)
        var = self.eps
        for i, ret in enumerate(r):
            var = self.lam * var + (1.0 - self.lam) * ret**2
            out[i] = np.log(self.eps + var)
        return out
