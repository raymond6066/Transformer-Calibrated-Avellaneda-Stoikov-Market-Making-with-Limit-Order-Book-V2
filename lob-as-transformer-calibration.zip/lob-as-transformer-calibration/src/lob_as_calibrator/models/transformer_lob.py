"""Compact spatio-temporal transformer for LOB state prediction."""

from __future__ import annotations

try:
    import torch
    from torch import nn
except Exception:  # pragma: no cover
    torch = None
    nn = None


class CompactLobTransformer(nn.Module if nn is not None else object):
    """Transformer encoder with multitask output heads.

    Input shape: batch x lookback x features.
    Output shape: batch x output_dim.
    """

    def __init__(
        self,
        n_features: int,
        output_dim: int,
        d_model: int = 64,
        n_heads: int = 4,
        n_layers: int = 2,
        dropout: float = 0.1,
        max_len: int = 512,
    ) -> None:
        if nn is None or torch is None:
            raise ImportError("Install torch to use CompactLobTransformer")
        super().__init__()
        self.input_projection = nn.Linear(n_features, d_model)
        self.pos_embedding = nn.Parameter(torch.zeros(1, max_len, d_model))
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_model * 4,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, output_dim),
        )

    def forward(self, x):
        if x.ndim != 3:
            raise ValueError("Expected input shape batch x lookback x features")
        lookback = x.shape[1]
        z = self.input_projection(x) + self.pos_embedding[:, :lookback, :]
        z = self.encoder(z)
        pooled = self.norm(z).mean(dim=1)
        return self.head(pooled)
