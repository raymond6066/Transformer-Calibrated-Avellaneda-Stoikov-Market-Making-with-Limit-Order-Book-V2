"""Plotting helpers for final report figures."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def plot_pnl(log: pd.DataFrame, out_path: str | Path) -> None:
    """Save a P&L time-series plot."""
    fig, ax = plt.subplots()
    ax.plot(log["t"], log["pnl"])
    ax.set_xlabel("Event time")
    ax.set_ylabel("Mark-to-market P&L")
    ax.set_title("Backtest P&L")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_inventory(log: pd.DataFrame, out_path: str | Path) -> None:
    """Save an inventory time-series plot."""
    fig, ax = plt.subplots()
    ax.plot(log["t"], log["inventory"])
    ax.set_xlabel("Event time")
    ax.set_ylabel("Inventory")
    ax.set_title("Inventory Path")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
