"""Backtest risk and execution metrics."""

from __future__ import annotations

import numpy as np
import pandas as pd


def max_drawdown(pnl: np.ndarray) -> float:
    pnl = np.asarray(pnl, dtype=float)
    if pnl.size == 0:
        return float("nan")
    running_max = np.maximum.accumulate(pnl)
    drawdowns = running_max - pnl
    return float(np.max(drawdowns))


def cvar_left_tail(returns: np.ndarray, alpha: float = 0.05) -> float:
    """Compute left-tail CVaR as the average return below the alpha quantile."""
    r = np.asarray(returns, dtype=float)
    if r.size == 0:
        return float("nan")
    threshold = np.quantile(r, alpha)
    tail = r[r <= threshold]
    return float(np.mean(tail)) if tail.size else float(threshold)


def summarize_backtest(log: pd.DataFrame, alpha: float = 0.05) -> dict[str, float]:
    """Summarize simulator output."""
    pnl = log["pnl"].to_numpy(dtype=float)
    dpnl = np.diff(pnl, prepend=pnl[0]) if len(pnl) else np.array([])
    inventory = log["inventory"].to_numpy(dtype=float) if "inventory" in log else np.array([])
    return {
        "final_pnl": float(pnl[-1]) if len(pnl) else float("nan"),
        "avg_pnl": float(np.mean(pnl)) if len(pnl) else float("nan"),
        "pnl_volatility": float(np.std(dpnl)) if len(dpnl) else float("nan"),
        "max_drawdown": max_drawdown(pnl),
        "cvar_left_tail": cvar_left_tail(dpnl, alpha=alpha),
        "mean_abs_inventory": float(np.mean(np.abs(inventory))) if len(inventory) else float("nan"),
        "p95_abs_inventory": float(np.quantile(np.abs(inventory), 0.95)) if len(inventory) else float("nan"),
        "fill_rate": float((log.get("bid_filled", False).mean() + log.get("ask_filled", False).mean()) / 2.0)
        if len(log)
        else float("nan"),
    }
