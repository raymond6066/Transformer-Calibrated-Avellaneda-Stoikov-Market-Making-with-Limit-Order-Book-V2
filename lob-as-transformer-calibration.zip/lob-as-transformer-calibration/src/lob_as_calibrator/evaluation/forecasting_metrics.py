"""Forecasting metrics for volatility and liquidity models."""

from __future__ import annotations

import numpy as np

from lob_as_calibrator.models.losses import qlike_loss


def mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.abs(np.asarray(y_true) - np.asarray(y_pred))))


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2)))


def r2_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    denom = np.sum((y_true - np.mean(y_true)) ** 2)
    if denom == 0:
        return float("nan")
    return float(1.0 - np.sum((y_true - y_pred) ** 2) / denom)


def volatility_metrics(y_true_var: np.ndarray, y_pred_var: np.ndarray) -> dict[str, float]:
    """Return a standard volatility metric dictionary."""
    return {
        "mae": mae(y_true_var, y_pred_var),
        "rmse": rmse(y_true_var, y_pred_var),
        "r2": r2_score(y_true_var, y_pred_var),
        "qlike": qlike_loss(y_true_var, y_pred_var),
    }
