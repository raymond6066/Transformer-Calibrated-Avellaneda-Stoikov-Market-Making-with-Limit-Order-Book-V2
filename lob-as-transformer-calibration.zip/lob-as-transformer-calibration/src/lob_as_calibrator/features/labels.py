"""Future volatility and liquidity label creation."""

from __future__ import annotations

import numpy as np
import pandas as pd


def future_realized_variance(log_returns: pd.Series | np.ndarray, horizon: int, eps: float = 1.0e-12) -> np.ndarray:
    """Compute future realized variance from t+1 through t+horizon.

    The label at index t uses returns strictly after t, which prevents the target
    from leaking into the input window ending at t.
    """
    if horizon < 1:
        raise ValueError("horizon must be positive")
    r = np.asarray(log_returns, dtype=float)
    out = np.full_like(r, fill_value=np.nan, dtype=float)
    squared = r**2
    for t in range(0, len(r) - horizon):
        out[t] = squared[t + 1 : t + horizon + 1].sum()
    return np.log(eps + out)


def future_average(values: pd.Series | np.ndarray, horizon: int) -> np.ndarray:
    """Compute future average from t+1 through t+horizon."""
    if horizon < 1:
        raise ValueError("horizon must be positive")
    x = np.asarray(values, dtype=float)
    out = np.full_like(x, fill_value=np.nan, dtype=float)
    for t in range(0, len(x) - horizon):
        out[t] = np.nanmean(x[t + 1 : t + horizon + 1])
    return out


def build_targets(
    features: pd.DataFrame,
    horizons: list[int],
    spread_col: str = "spread",
    depth_col: str = "cum_bid_depth_10",
    imbalance_col: str = "imbalance_10",
) -> pd.DataFrame:
    """Build multi-horizon volatility and liquidity labels."""
    if "log_return" not in features:
        raise KeyError("features must contain log_return")
    rows: dict[str, np.ndarray] = {}
    for h in horizons:
        rows[f"log_rv_h{h}"] = future_realized_variance(features["log_return"], h)
        rows[f"avg_spread_h{h}"] = future_average(features[spread_col], h)
        rows[f"avg_depth_h{h}"] = future_average(features[depth_col], h)
        rows[f"avg_imbalance_h{h}"] = future_average(features[imbalance_col], h)
    return pd.DataFrame(rows, index=features.index)


def drop_unaligned(features: pd.DataFrame, targets: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Drop rows where future labels are not available."""
    mask = targets.notna().all(axis=1)
    return features.loc[mask].copy(), targets.loc[mask].copy()
