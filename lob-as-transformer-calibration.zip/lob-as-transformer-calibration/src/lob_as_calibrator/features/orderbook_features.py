"""Feature engineering for Level-10 limit order books."""

from __future__ import annotations

import numpy as np
import pandas as pd


def _require_columns(df: pd.DataFrame, columns: list[str]) -> None:
    missing = [col for col in columns if col not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")


def build_lob_features(df: pd.DataFrame, levels: int = 10, eps: float = 1.0e-12) -> pd.DataFrame:
    """Build transparent microstructure features from a Level-N order book."""
    required = ["ask_price_1", "bid_price_1", "ask_size_1", "bid_size_1"]
    _require_columns(df, required)
    out = df.copy()

    out["mid_price"] = (out["ask_price_1"] + out["bid_price_1"]) / 2.0
    out["spread"] = out["ask_price_1"] - out["bid_price_1"]
    out["micro_price"] = (
        out["ask_price_1"] * out["bid_size_1"] + out["bid_price_1"] * out["ask_size_1"]
    ) / (out["ask_size_1"] + out["bid_size_1"] + eps)

    bid_size_cols = [f"bid_size_{i}" for i in range(1, levels + 1) if f"bid_size_{i}" in out]
    ask_size_cols = [f"ask_size_{i}" for i in range(1, levels + 1) if f"ask_size_{i}" in out]
    out[f"cum_bid_depth_{levels}"] = out[bid_size_cols].sum(axis=1)
    out[f"cum_ask_depth_{levels}"] = out[ask_size_cols].sum(axis=1)
    denom = out[f"cum_bid_depth_{levels}"] + out[f"cum_ask_depth_{levels}"] + eps
    out[f"imbalance_{levels}"] = (out[f"cum_bid_depth_{levels}"] - out[f"cum_ask_depth_{levels}"]) / denom

    mid = out["mid_price"].astype(float).clip(lower=eps)
    out["log_return"] = np.log(mid).diff().fillna(0.0)
    return out


def feature_matrix(df: pd.DataFrame, columns: list[str] | None = None) -> np.ndarray:
    """Return a numeric feature matrix from selected columns."""
    if columns is None:
        columns = [col for col in df.columns if pd.api.types.is_numeric_dtype(df[col])]
    return df[columns].to_numpy(dtype=np.float64)
