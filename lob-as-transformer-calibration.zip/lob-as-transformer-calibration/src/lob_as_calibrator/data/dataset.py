"""Windowed datasets for LOB forecasting."""

from __future__ import annotations

import numpy as np

try:
    import torch
    from torch.utils.data import Dataset
except Exception:  # pragma: no cover - torch is optional in base install
    torch = None
    Dataset = object


class WindowedLobDataset(Dataset):
    """PyTorch dataset that returns rolling LOB windows and aligned targets."""

    def __init__(self, features: np.ndarray, targets: np.ndarray, lookback: int) -> None:
        if torch is None:
            raise ImportError("Install the torch extra to use WindowedLobDataset: pip install -e '.[torch]'")
        if lookback < 1:
            raise ValueError("lookback must be positive")
        if len(features) != len(targets):
            raise ValueError("features and targets must have the same number of rows")
        if len(features) <= lookback:
            raise ValueError("features length must exceed lookback")
        self.features = np.asarray(features, dtype=np.float32)
        self.targets = np.asarray(targets, dtype=np.float32)
        self.lookback = int(lookback)

    def __len__(self) -> int:
        return len(self.features) - self.lookback + 1

    def __getitem__(self, idx: int):
        start = idx
        end = idx + self.lookback
        x = self.features[start:end]
        y = self.targets[end - 1]
        return torch.from_numpy(x), torch.from_numpy(y)
