"""Load FI-2010-style limit order book data."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


def default_lob_columns(levels: int = 10) -> list[str]:
    """Return canonical Level-N LOB column names.

    The order is ask price, ask size, bid price, bid size for each level.
    Adjust this mapping if your raw source uses a different convention.
    """
    cols: list[str] = []
    for level in range(1, levels + 1):
        cols.extend([
            f"ask_price_{level}",
            f"ask_size_{level}",
            f"bid_price_{level}",
            f"bid_size_{level}",
        ])
    return cols


def load_csv_orderbook(path: str | Path, parse_dates: Iterable[str] | None = None) -> pd.DataFrame:
    """Load an order book CSV file into a DataFrame."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Order book file not found: {path}")
    return pd.read_csv(path, parse_dates=list(parse_dates) if parse_dates else None)


def load_fi2010_matrix(path: str | Path, delimiter: str | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Load a FI-2010 matrix-form file.

    Many FI-2010 files are stored as matrices where rows 0:144 are features and
    rows 144:149 are labels for five horizons. This function returns arrays with
    samples on rows.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"FI-2010 file not found: {path}")
    raw = np.loadtxt(path, delimiter=delimiter)
    if raw.ndim != 2 or raw.shape[0] < 149:
        raise ValueError("Expected matrix with at least 149 rows: 144 features + 5 label rows")
    features = raw[:144, :].T.astype(np.float64, copy=False)
    labels = raw[144:149, :].T.astype(np.int64, copy=False)
    return features, labels


def matrix_to_level10_dataframe(features: np.ndarray, levels: int = 10) -> pd.DataFrame:
    """Convert the first 40 FI-2010 features to a Level-10 book DataFrame.

    The exact raw feature order should be verified against the team dataset. This
    helper assumes the common 4-values-per-level LOB ordering.
    """
    needed = levels * 4
    if features.shape[1] < needed:
        raise ValueError(f"Need at least {needed} features for Level-{levels} LOB data")
    return pd.DataFrame(features[:, :needed], columns=default_lob_columns(levels))
