"""Preprocessing utilities with chronological splitting and no-leakage scaling."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class ChronologicalSplit:
    """Container for chronological train, validation, and test segments."""

    train: pd.DataFrame | np.ndarray
    val: pd.DataFrame | np.ndarray
    test: pd.DataFrame | np.ndarray


def chronological_split(
    data: pd.DataFrame | np.ndarray,
    ratios: tuple[float, float, float] = (0.70, 0.15, 0.15),
) -> ChronologicalSplit:
    """Split data in time order without shuffling."""
    if not np.isclose(sum(ratios), 1.0):
        raise ValueError("Split ratios must sum to 1.0")
    n = len(data)
    if n < 3:
        raise ValueError("Need at least three observations for train/val/test split")
    n_train = int(n * ratios[0])
    n_val = int(n * ratios[1])
    train = data[:n_train]
    val = data[n_train : n_train + n_val]
    test = data[n_train + n_val :]
    return ChronologicalSplit(train=train, val=val, test=test)


@dataclass
class Standardizer:
    """Standardize features using statistics fitted on training data only."""

    mean_: np.ndarray | None = None
    scale_: np.ndarray | None = None
    eps: float = 1.0e-12

    def fit(self, x: np.ndarray) -> "Standardizer":
        x = np.asarray(x, dtype=float)
        self.mean_ = np.nanmean(x, axis=0)
        scale = np.nanstd(x, axis=0)
        self.scale_ = np.where(scale < self.eps, 1.0, scale)
        return self

    def transform(self, x: np.ndarray) -> np.ndarray:
        if self.mean_ is None or self.scale_ is None:
            raise RuntimeError("Standardizer must be fitted before transform")
        return (np.asarray(x, dtype=float) - self.mean_) / self.scale_

    def fit_transform(self, x: np.ndarray) -> np.ndarray:
        return self.fit(x).transform(x)
