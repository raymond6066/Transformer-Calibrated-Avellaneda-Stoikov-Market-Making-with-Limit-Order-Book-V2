"""LOB state calibration for Avellaneda-Stoikov market-making research."""

__all__ = ["__version__"]
__version__ = "0.1.0"
