"""Volatility calibration from model outputs."""

from __future__ import annotations

import numpy as np


def log_variance_to_sigma2(
    log_variance: np.ndarray,
    min_sigma2: float = 1.0e-12,
    max_sigma2: float = 1.0,
) -> np.ndarray:
    """Convert log realized variance predictions to positive variance estimates."""
    sigma2 = np.exp(np.asarray(log_variance, dtype=float))
    return np.clip(sigma2, min_sigma2, max_sigma2)


def annualize_variance(sigma2: np.ndarray, factor: float) -> np.ndarray:
    """Scale event-time variance by an external annualization or horizon factor."""
    if factor <= 0:
        raise ValueError("factor must be positive")
    return np.asarray(sigma2, dtype=float) * factor
