"""Liquidity calibration for Avellaneda-Stoikov k parameter."""

from __future__ import annotations

import numpy as np


def liquidity_to_k(
    spread: np.ndarray,
    depth: np.ndarray,
    min_k: float = 1.0e-6,
    max_k: float = 1.0e6,
    eps: float = 1.0e-12,
) -> np.ndarray:
    """Map spread and depth proxies to a positive arrival-decay parameter k.

    This simple monotone mapping is a starting point: deeper and tighter books
    imply larger k, while wider and thinner books imply smaller k.
    """
    spread = np.asarray(spread, dtype=float)
    depth = np.asarray(depth, dtype=float)
    raw = depth / (np.abs(spread) + eps)
    return np.clip(raw, min_k, max_k)
