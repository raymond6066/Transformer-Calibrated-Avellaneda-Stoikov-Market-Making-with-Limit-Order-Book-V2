# Codex Prompt for Repository Completion

You are assisting with an MScFE 690 capstone repository titled `Transformer-Calibrated Avellaneda-Stoikov Market Making`.

## Objective

Complete and harden the repository so it can run a reproducible experiment on FI-2010 Level-10 limit order book data. The system should forecast future realized volatility and liquidity states, calibrate those predictions into Avellaneda-Stoikov inputs, and evaluate market-making risk behavior.

## Rules

1. Keep the project a research simulator. Do not add broker, exchange, or live-trading integrations.
2. Use chronological splits only.
3. Fit normalizers using training data only.
4. Preserve label alignment tests and no-leakage tests.
5. Add docstrings and type hints for every public function.
6. Keep modules small and testable.
7. Run `pytest` after every meaningful change.

## Priority tasks

1. Add a robust FI-2010 loader for the exact raw files used by the team.
2. Build an experiment script that creates features, labels, splits, datasets, and predictions.
3. Train and save rolling, EWMA, MLP, and transformer forecasts.
4. Add Diebold-Mariano testing for forecast loss comparisons.
5. Add regime-sliced evaluation by realized volatility decile and spread/depth regimes.
6. Extend the simulator with transaction costs, latency delay, and simple queue-position assumptions.
7. Generate final tables and plots for the report.

## Acceptance criteria

- `pytest` passes.
- The README quick start works.
- A small synthetic example can run end-to-end without external data.
- All outputs are saved with config, seed, and timestamp metadata.
- The final notebook or script produces forecast metrics and backtest metrics tables.
