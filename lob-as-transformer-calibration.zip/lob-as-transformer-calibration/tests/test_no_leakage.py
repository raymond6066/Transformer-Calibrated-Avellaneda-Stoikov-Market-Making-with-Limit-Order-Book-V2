import numpy as np

from lob_as_calibrator.data.preprocessing import Standardizer, chronological_split


def test_chronological_split_order():
    x = np.arange(10)
    split = chronological_split(x, ratios=(0.6, 0.2, 0.2))
    assert split.train.tolist() == [0, 1, 2, 3, 4, 5]
    assert split.val.tolist() == [6, 7]
    assert split.test.tolist() == [8, 9]


def test_standardizer_fit_uses_train_only():
    train = np.array([[0.0], [2.0]])
    test = np.array([[100.0]])
    scaler = Standardizer().fit(train)
    transformed = scaler.transform(test)
    assert scaler.mean_[0] == 1.0
    assert transformed[0, 0] == 99.0
