from lob_as_calibrator.market_making.avellaneda_stoikov import ASParams, make_quotes, reservation_price


def test_quotes_are_ordered():
    bid, ask = make_quotes(mid=100.0, inventory=0, sigma2=1e-4, k=1000.0, tau=1.0, params=ASParams())
    assert bid < ask


def test_positive_inventory_lowers_reservation_price():
    flat = reservation_price(100.0, inventory=0, gamma=0.01, sigma2=0.1, tau=1.0)
    long = reservation_price(100.0, inventory=10, gamma=0.01, sigma2=0.1, tau=1.0)
    assert long < flat
