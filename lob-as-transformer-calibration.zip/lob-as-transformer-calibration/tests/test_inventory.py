from lob_as_calibrator.market_making.simulator import AccountState, update_account


def test_bid_fill_buys_inventory_and_reduces_cash():
    new_state = update_account(AccountState(), bid=99.0, ask=101.0, bid_filled=True, ask_filled=False)
    assert new_state.inventory == 1
    assert new_state.cash == -99.0


def test_ask_fill_sells_inventory_and_increases_cash():
    new_state = update_account(AccountState(), bid=99.0, ask=101.0, bid_filled=False, ask_filled=True)
    assert new_state.inventory == -1
    assert new_state.cash == 101.0
