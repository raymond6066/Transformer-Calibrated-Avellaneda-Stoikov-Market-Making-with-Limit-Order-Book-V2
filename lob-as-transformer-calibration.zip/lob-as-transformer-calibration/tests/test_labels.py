import numpy as np

from lob_as_calibrator.features.labels import future_average, future_realized_variance


def test_future_average_uses_future_only():
    x = np.array([10.0, 20.0, 30.0, 40.0])
    out = future_average(x, horizon=2)
    assert out[0] == 25.0
    assert out[1] == 35.0
    assert np.isnan(out[-2])
    assert np.isnan(out[-1])


def test_future_realized_variance_alignment():
    r = np.array([0.0, 0.1, 0.2, 0.3])
    out = future_realized_variance(r, horizon=2, eps=0.0)
    expected = np.log(0.1**2 + 0.2**2)
    assert np.isclose(out[0], expected)
    assert np.isnan(out[-2])
    assert np.isnan(out[-1])
