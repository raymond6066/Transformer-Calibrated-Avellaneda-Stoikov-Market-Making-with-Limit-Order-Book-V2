"""Training entry point scaffold.

This script intentionally leaves dataset-specific wiring to the team. Use Codex
or manual development to connect the exact FI-2010 raw files used in the project.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import yaml


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/default.yaml")
    args = parser.parse_args()
    with Path(args.config).open("r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    print("Loaded config for training scaffold:")
    print(config)
    print("Next step: connect data loader, feature builder, targets, and model training loop.")


if __name__ == "__main__":
    main()
