"""Synthetic backtest demo for the Avellaneda-Stoikov simulator."""

from __future__ import annotations

import numpy as np

from lob_as_calibrator.evaluation.backtest_metrics import summarize_backtest
from lob_as_calibrator.market_making.avellaneda_stoikov import ASParams
from lob_as_calibrator.market_making.simulator import replay_as_strategy


def main() -> None:
    rng = np.random.default_rng(42)
    n = 500
    mid = 100 + np.cumsum(rng.normal(0, 0.01, size=n))
    sigma2 = np.full(n, 1.0e-4)
    k = np.full(n, 5_000.0)
    log = replay_as_strategy(mid, sigma2, k, ASParams(gamma=0.01, tick_size=0.01, max_inventory=20))
    print(summarize_backtest(log))


if __name__ == "__main__":
    main()
